<link rel="Stylesheet" href="styles/style.css" type="text/css" />
<!--[if IE 6]>
<link href="styles/ie.css" rel="stylesheet" type="text/css" />	
<![endif]-->

<!--[if gte IE 7]>
<link href="styles/ie7.css" rel="stylesheet" type="text/css" />	
<![endif]-->
<style type="text/css">
<!--
.style4 {font-size: 12px}
-->
</style>
<div id="flyer_section">
	
    <div id="flyer_header">
    	<div id="logo_nplink"></div>
        <div id="migration_title">
        		<div id="left_bg"></div>
                <div id="main_bg_m">
                	<p>Website Migration Offer!</p>
          </div>
        </div>
  </div>
    
    <div id="flyer_main">
    
    	<div id="flyer_main_left">
        <h2>WEB HOSTING FEATURES</h2>
        <p>
        <span><img src="images/flyerimages/webspace.png">10 GB Web Space</span>
        <span><img src="images/flyerimages/data_transfer.jpg">100 GB Monthly Data Transfer</span>

	<span><img src="images/flyerimages/domain_registration.jpg">Domain Registeration FREE!</span>

    <span><img src="images/flyerimages/unlimited_email.jpg">Unlimited Email</span>

    <span><img src="images/flyerimages/unlimited_database.jpg">Unlimited Database</span>

    <span><img src="images/flyerimages/unlimited_subdomain.jpg">Unlimited Subdomain</span>

    <span><img src="images/flyerimages/php.jpg">Php5-Perl-Python-Ruby</span>

    <span><img src="images/flyerimages/mysql.jpg">MySql-PostgreSQL</span>

    <span><img src="images/flyerimages/cpanel.jpg">cPanel</span>

    <span><img src="images/flyerimages/24x7server.jpg">27x7 Server Moniter</span>

    <span><img src="images/flyerimages/moneyback_gurantee.jpg">30-day Money Guanrantee</span>

    <span><img src="images/flyerimages/livesupport.jpg">      Live Support &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      </span>
</p>
        </div>
        
      <div id="flyer_main_right">
       <p>&nbsp;&nbsp;<img src="images/flyerimages/we_hosting.jpg"></p>
      </div>
       <div id="offer">
       <div id="moneyback"></div>
       <div id="freedomain"></div>
      </div>
      
      <div id="amount">
      	<div id="text5">All Cost You </div>
        <div id="text6">Rs.166/mt</div>
        <div id="text7"><a href="http://nepallink.net/order.php?plan=10GBLNX_MIGRATION"><img src="images/order_blue.gif" width="120" height="26" border="0" /></a></div>
        <br>
        <br><br>
        <br>
      </div>
        <br clear="all">
    </div>
    
  <div id="flyer_bg"></div>
    <div id="flyer_footer_setion">	
   	 	<div id="contact_section">
    		<div id="contact_details">
            <b>Contact us</b><br>
            Sales: sales@nepallink.net<br>
            Phone: +977 1 441.7360<br>
Cell: +977 9841262275<br>
Fax +977 1 411.1094<br>
URL: www.nepallink.net
            </div>
            <div id="contact_details">
              <p><b>Postal Address</b><br>
                Keshar Mahal<br>
                Thamel, Kathmandu<br>
                Nepal <br />
</p>
            </div>
            
            <div id="flyer_sepr"></div>
            
	  </div>
         
         		<div id="cms_features">
				<div id="cms_footer_content">
                	<ul>
                	  <li><b align="left">Ready to Install </b><b> Drupal</b></li>
              	      <li><strong>Ready to Install  Wordpress</strong></li>
               	      <li><strong>Ready to Install E-commerce applications</strong></li>
               	      <li><strong>Free Gallery, Web Calendar, Support tools </strong></li>
               	      <li><strong>Free Bloggings Space </strong></li>
               	      <li><strong>More than 2 dozen applications to install</strong></li>
               	      <li><strong>Auto Update, Latest cPanel, OS, 99% live </strong></li>
               	      <li><strong>Online one click backup </strong></li>
               	      <li><strong>Free Marketing Tools</strong></li>
               	      <li><strong>Special Discount in SEO package</strong></li>
               	      <li><strong>Special offer in Re-desiging old website</strong></li>
               	      <li><strong>Special offer in static to dyanmic package</strong></li>
               	      <li>Free Newsletter scripts </li>
               	      <li><strong>Install ZenCart,  Os Commerce in 1 click</strong><br />
           	            </li>
               	  </ul>
               	  </div>
      </div>
    </div>
</div>
