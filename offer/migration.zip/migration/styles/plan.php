

<div id="main_section">



	<div id="special_offer">

    	<div id="special_offer_title"><span>Special Offer !</span></div>

  <div  id="special_offer_ul">

        <ul>

        	<li>2 GB space, ASP.NET, PHP</li>

            <li>One Domain FREE!</li>

            <li>Rs 3000/year !</li>

            <li>Plesk CP</li>

        </ul>

        </div>

        <div id="links">

        <div id="link_details"><a href='http://nepallink.net/services/special_offer.php'>see details</a></div><div id="link_order"><a href='order.php?plan=WINSPCL08'>order now</a></div>

        </div>

    </div>

    <div id="separator"></div>

   	<div id="bronze">

    	<div id="bronze_title"><span>Bronze Plan</span></div>

        

        <div id="price">

        <div class="rs">Rs.</div>

        <div class="amount">2000/-</div>

        <div class="year">per year</div>

        </div>

		<div id="section_contents">

         <ul>

        	<li>5 GB Storage space</li>

			<li>100 GB Data Tranfer</li>

			<li><span class="text2">30-day Money Back</span></li>

			<li>Unlimited Email/Database</li>

			<li>4000 MB Blog Space</li>

        </ul>

		</div>

		<div id="links">

        <div id="link_details"><a href="Nepal_Web_Hosting_Bronze">more details</a></div><div id="link_order"><a href="Nepal_Web_Hosting_Bronze_ORDER">order now</a></div>

        </div>



    </div>

    <div id="separator"></div>

    

    <div id="gold">

    	<div id="gold_title">

        <span>Gold Plan</span>

        </div>

        <div id="price2">

        <div class="rs">Rs.</div>

       <div class="amount">3000/-</div>

        <div class="year">per year</div>

        </div>

    	<div id="section_contents">

         <ul>

        	<li>10 GB Storage space</li>

			<li>500 GB Data Tranfer</li>

			<li><span class="text2">30-day Money Back</span></li>

			<li>Unlimited Email/Database</li>

			<li>4000 MB Blog Space</li>

        </ul>

		</div>

        <div id="links">

        <div id="link_details"><a href="Nepal_Web_Hosting_Gold">more details</a></div><div id="link_order"><a href="Nepal_Web_Hosting_Gold_ORDER">order now</a></div>

        </div>

    </div>

    

    <div id="separator"></div>

    

    <div id="platinum">

    	<div id="platinum_title">

        <span>Platinum Plan</span>

        </div>

         <div id="price3">

        <div class="rs">Rs.</div>

        <div class="amount">5000/-</div>

        <div class="year">per year</div>

        </div>

        <div id="section_contents_platinum">

         <ul>

        	<li>1000 GB Storage space</li>

			<li><b>Free Domain Registration</b></li>

			<li><span class="text2">30-day Money Back</span></li>

			<li>Unlimited Email/Database</li>

			<li>20 GB File Transfer</li>

        </ul>

		</div>

        <div id="links">

        <div id="link_details"><a href="Nepal_Web_Hosting_Plantnium">more details</a></div><div id="link_order"><a href="Nepal_Web_Hosting_Plantnium_ORDER">order now</a></div>

        </div>

    </div>



</div>

<br clear="all" />